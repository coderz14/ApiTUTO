<?php

// Définir les en-têtes pour autoriser les requêtes provenant de n'importe quel domaine
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Vérifier l'en-tête Authorization pour le jeton d'authentification
$token = $_SERVER['HTTP_AUTHORIZATION'];

// Vérifier si le jeton est valide (à remplacer par votre propre système d'authentification)
$valid_tokens = array("secret_token_1", "secret_token_2");
if (!in_array($token, $valid_tokens)) {
    http_response_code(401); // Unauthorized
    echo json_encode(array("error" => "Unauthorized"));
    exit;
}

// Connexion à la base de données (à remplacer par vos propres informations de connexion)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "books";

$conn = new mysqli($servername, $username, $password, $dbname);


// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Gestion des différentes méthodes HTTP
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
     
    case 'POST':
     $data = json_decode(file_get_contents('php://input'), true);



        $task_name = $data['name'];
        // Ajouter une nouvelle tâche
       $sql = "SELECT * FROM booksList where name REGEXP ? ";
        $result = $conn->prepare($sql);

            $result->bind_param("s", $task_name);

             $result->execute();

        if ($result->num_rows > 0) {
            $tasks = array();
            while ($row = $result->fetch_assoc()) {
                $tasks[] = $row;
            }
           return json_encode($tasks);
        } else {
           return json_encode(array());
        }
        break;
    
}


// Fermer la connexion à la base de données
$conn->close();


return json_encode(array('dqtq'));

?>
