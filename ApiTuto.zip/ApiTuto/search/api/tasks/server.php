<?php

// Définir les en-têtes pour autoriser les requêtes provenant de n'importe quel domaine
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

 



// Vérifier si le jeton est valide (à remplacer par votre propre système d'authentification)
$valid_tokens = array("secret_token_1", "secret_token_2");
 

// Connexion à la base de données (à remplacer par vos propres informations de connexion)
 
$conn =   new PDO('mysql:host=localhost;dbname=books', 'root', '');

//on recupere les methodes
$headers = getallheaders() ;

 $token = explode(' ', $headers['Authorization'])[1];
 
// Gestion des différentes méthodes HTTP
$method = $_SERVER['REQUEST_METHOD'];


$valid_tokens = array("secret_token_1", "secret_token_2");
if (!in_array($token, $valid_tokens)) {
    http_response_code(401); // Unauthorized
    echo json_encode(array("error" => "Unauthorized"));
    exit;
}


 

if ($_SERVER['REQUEST_METHOD'] =='POST') {
    # code...
    $data = json_decode(file_get_contents('php://input'), true);

 

        $task_name = $data['name'];
        // Ajouter une nouvelle tâche
       $sql = "SELECT * FROM booksList where name REGEXP :name ";
        $result = $conn->prepare($sql);

   

             $result->execute(array(":name"=>$task_name));


 


     
 
            $tasks = array();

            $count = 0 ;

            while ($row = $result->fetch()) {

               
                $tasks[] = $row;

                  

                
            }


             
      echo json_encode($tasks);       
       

}
 
     

// Fermer la connexion à la base de données


 
?>
