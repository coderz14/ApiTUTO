 

<?php

if(isset($_POST['rechercher']))

{


function createTask($token, $taskName) {
    $url = 'http://localhost/search/api/tasks'; // Remplacez par l'URL de votre API
    $data = array('name' => $taskName);
    $data_string = json_encode($data);
//On initialize CURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  //L’entete
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Bearer ' . $token, // Remplacez le jeton avec votre jeton d'authentification valide
        'Content-Type: application/json',
        'Content-Length: ' . strlen($data_string) ));
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    $response = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($response, true);
     return $result;}
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Recherche livre</title>
</head>
<body>

    <h4>Bienvenu sur super-Coding</h4>

    <?php

if(!isset($_POST['fichierRechercher']))

{
print_r($_POST);

    ?>

    <form method="post" action="/client">
        
<p>Rechercher votre fichier  <input type="text" name="fichierRechercher"> </p>

<p><input type="submit" name="rechercher" value="rechercher"></p>
    </form>

<?php
}else { 
?>
<p>Resultats : 


    <p>Resultats : 
<?php 

$taskName = $_POST['fichierRechercher'] ;

$results = createTask($token, $taskName) ;

if(!empty($results))
{ 
foreach ($results as $result) {
    # code...
    ?>
<?php } } else{?>

<h5>Aucun resultat trouver</h5>

<?php }}?>
</body>
</html>