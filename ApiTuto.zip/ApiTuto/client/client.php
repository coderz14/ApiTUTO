 

<?php

if(isset($_POST['rechercher']))

{


function createTask($token, $taskName) {
    $url = 'http://localhost/search/api/tasks/server.php'; // Remplacez par l'URL de votre API
    $data = array('name' => $taskName);
    $data_string = json_encode($data);


 
//On initialize CURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  //L’entete
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Bearer ' . $token, // Remplacez le jeton avec votre jeton d'authentification valide
        'Content-Type: application/json',
        'Content-Length: ' . strlen($data_string) ));
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);


    $response = curl_exec($ch);
    curl_close($ch);

        
return $response;
      
 


 }
}

?>

<!DOCTYPE html>
<html>
<head>
    <style type="text/css">
        

        td{border: solid black 1px;}

        table{border-collapse: collapse;}
    </style>
    <title>Recherche livre</title>
</head>
<body>

    <h4>Bienvenu sur super-Coding</h4>

    <?php

if(!isset($_POST['fichierRechercher']))

{


    ?>

    <form method="post" action="/client/client.php">
        
<p>Rechercher votre fichier  <input type="text" name="fichierRechercher" placeholder="programmation"> </p>

<p><input type="submit" name="rechercher" value="rechercher"></p>
    </form>

<?php
}else { 
?>


 
<?php 

$taskName = $_POST['fichierRechercher'] ;


$token = 'secret_token_1';

$results = createTask($token, $taskName) ;

$results = json_decode($results, true);


if(!empty($results) && array_column($results, 'name') )
{ 

  
 ?>
 <div style="width: 350px; /* On a indiqué une largeur (obligatoire) */
margin: auto; /* On peut donc demander à ce que le bloc soit
centré avec auto */
border: 1px solid black;
text-align: justify;
padding: 12px;
margin-bottom: 20px;">

 <p ><?php echo count($results) ?> resultats trouvées</p> 

<table >

    <tr><td>Fichier</td> <td>date de creation</td></tr>

 <?php



foreach ($results as $result) {
    # code...
    echo "<tr><td><a href='".$result['link']."'> ".$result['name'] ."</a></td> <td>".date('d-m-Y', strtotime($result['date_create']))  ."</td></tr>";
    ?>

    
<?php }?> </table>
         </div><?php } else{?>

<h5>Aucun resultat trouver</h5>

<?php }}?>
</body>
</html>